import { HorizontalScrollDirective } from './horizontal-scroll.directive';

describe('HorizontalScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new HorizontalScrollDirective();
    expect(directive).toBeTruthy();
  });
});
