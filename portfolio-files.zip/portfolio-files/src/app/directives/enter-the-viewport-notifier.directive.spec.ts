import { EnterTheViewportNotifierDirective } from './enter-the-viewport-notifier.directive';

describe('EnterTheViewportNotifierDirective', () => {
  it('should create an instance', () => {
    const directive = new EnterTheViewportNotifierDirective();
    expect(directive).toBeTruthy();
  });
});
