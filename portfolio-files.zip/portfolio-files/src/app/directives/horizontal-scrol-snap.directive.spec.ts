import { HorizontalScrollSnapDirective } from './horizontal-scroll-snap.directive';

describe('HorizontalScrolSnapDirective', () => {
  it('should create an instance', () => {
    const directive = new HorizontalScrollSnapDirective();
    expect(directive).toBeTruthy();
  });
});
