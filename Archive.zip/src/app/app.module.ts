import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FrameComponent } from './components/frame/frame.component';
import { NavigationBarComponent } from './components/navigation-bar/navigation-bar.component';
import { AboutMeComponent } from './components/about-me/about-me.component';
import { ToolsComponent } from './components/tools/tools.component';
import { EnterTheViewportNotifierDirective } from './directives/enter-the-viewport-notifier.directive';
import { WhatIDoComponent } from './components/what-i-do/what-i-do.component';
import { ProjectsComponent } from './components/projects/projects.component';
import { ContactsComponent } from './components/contacts/contacts.component';

@NgModule({
  declarations: [
    AppComponent,
    FrameComponent,
    NavigationBarComponent,
    AboutMeComponent,
    ToolsComponent,
    EnterTheViewportNotifierDirective,
    WhatIDoComponent,
    ProjectsComponent,
    ContactsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
