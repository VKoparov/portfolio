import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.scss']
})
export class NavigationBarComponent {

  @Input() windowLocation: string = 'app-about-me';

  @Output() skipLocation = new EventEmitter<string>();

  scrollIntoObject(elementId: string) {
    this.windowLocation = elementId;
    this.skipLocation.emit(elementId);
    (document.getElementsByTagName(elementId)[0] as HTMLElement)
      .scrollIntoView({behavior: 'smooth'});
  }
}
